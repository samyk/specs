% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

function [Y] = IIR(X,p, filterStart, constantOffset)
%   [Y] = IIR(X,p, filterStart, constantOffset)
%
%   Y[n] = (1-1/2^p)*Y[n-1] + (1/2^p)*X[n]
%
%     Inputs:
%         X - Vector to be filtered.
%         p - Filter power.
%         filterStart - Index to start the filtering from. Used to start
%         filtering only after the input vector X is stable. filterStart =
%         [] will initiate a default value of 1.  
%         constantOffset - The filter is initiated such that Y[filterStart]
%         = X[filterStart] + constantOffset. constantOffset = [] will
%         initiate a default value of 0. 
%
%     Outputs:
%         Y - Filtered vector.
        
    Y = zeros(size(X));
    
    b = 1/2^p;
    a = [1, -(1-b)];

    if isempty(filterStart)
        filterStart = 1;
    end
    
    if (isempty(constantOffset))
        constantOffset = 0;
    end
    
    Y(1:filterStart) = X(1:filterStart);
    Y(filterStart:end) = filter(b,a,X(filterStart:end), (1-b)*X(filterStart) + constantOffset);
end

