% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


function [F_sr, O_sr, F_mr, O_mr] = time_sync_domain(domain, w, sync_int, quantization)
% intra-domain handshake process
% assumes 3 routers : slave, master, grandmaster.
%     Inputs:
%         
%         domain- domain parameters struct:
%             .t_vec_ms- Handshake time stamps matrix of the master - slave sync, each row is (t1 t2 t3 t4), matrix dimensions are (number of handshakes) X (4).
%             .t_vec_rm- Handshake time stamps matrix of the grandmaster - master sync, each row is (t1 t2 t3 t4), matrix dimensions are (number of handshakes) X (4).
%             .slave_params - struct of slave parameters, following
%             parameters are used in this function:
%                   .slave_params.inc 
%             .master_params - struct of master parameters, following
%             parameters are used in this function:
%                   .master_params.inc 
%             .master_params - struct of master parameters, following
%             parameters are used in this function:
%                   .grandmaster_params.inc
%             domain.filters- Filters power parameters struct: 
%                 .p_T- Power of time offset filtering.
%                 .p_D- Power of propagation delay filtering.
%                 .p_F- Power of frequency offset filtering.
%         w- number of handshakes between frequency offset calculation.
%         sync_int- time between handshakes.
%         quantization- Quantization parameters struct:
%             .stamp_max_val- max value of local time counter (Figure 7-3)
%             .stamp_num_bits- numbtmuer of bits of local time counter (Figure 7-3)
%             .freq_off_max_val- max value of frequency offset (Figure 7-5)
%             .freq_off_num_bits- number of bits of frequency offset (Figure 7-5)
%             .time_offset_max_val- max value of time offset (Figure 7-4)
%             .time_offset_num_bits- number of bits of time offset (Figure 7-4)
%             
%     Outputs:
%         
%         F_sr- Vector of frequency offsets, F(S,R), between Slave router and Grandmaster router in the domain.
%         O_sr- Vector of time offsets, O(S,R), between Slave router and Grandmaster router in the domain.
%         F_mr- Vector of frequency offsets, F(M,R), between Master router and Grandmaster router in the domain.
%         O_mr- Vector of time offsets, O(M,R), between Master router and Grandmaster router in the domain.

% When processing the handshake matrix between 2 routers, it is required that the
% handshake results matrices of other pairs will be aligned to this matrix
% It means that for every row containing a t1, t2, t3, t4 tuple, the
% approriate row in the other matrices will be the one that can be used for
% the calculations of the equations in the spec

% In other words, the appropriate row in the other matrices
% whould correspond to the latest available handshake 
% the function get_index_offset_for_t_vec_sync is used to generate an index
% vector for this alignment

% Here we want to align the handshake matrix domain.t_vec_rm to the
% handshake matrix domain.t_vec_ms. First we call
% get_index_offset_for_t_vec_sync to get the index vector index_ms_rm.
% Then, t_vec_rm(index_ms_rm,:) can be used with t_vec_ms such that every
% row in t_vec_ms can be used with the appropriate row in
% t_vec_rm(index_ms_rm,:). The function get_index_offset_for_t_vec_sync
% uses the master clock to perform the alignment (by comparing t3 of the
% slave side to t4 of the grandmaster side)


[index_ms_rm, ~] = get_index_offset_for_t_vec_sync(...
    domain.t_vec_ms(:,3), domain.t_vec_rm(:,4), domain.follow_up_offest);

% grandmaster - master sync process.
[F_mr, O_mr, F_mr_original, O_mr_original, D_rm, ~, ~, ~] = ...
    time_sync_pair(domain.t_vec_rm,...
    sync_int, w, domain.filters, quantization,...
    [], [], [], [], ...
    [], [], [], [], ...
    [], [], [], []);      

% master - slave sync process.
[F_sr, O_sr, F_sm, O_sm, D_ms, ~, ~, ~] = ...
    time_sync_pair(domain.t_vec_ms,...
    sync_int, w, domain.filters, quantization,...
    domain.t_vec_rm(index_ms_rm,4), O_mr(index_ms_rm), F_mr(index_ms_rm), find(index_ms_rm >= w + 1, 1),...
    [], [], [], [],...
    [], [], [], []);



if domain.print_on
    % print various results internal to the domain
    
    % calculate grandmaster time stamp at slave and compare to reference
    
    % generate a vector t_now_vec of time points at which the comparison to
    % the reference will be done
    % The reference time points are synced to the edges of the grandmaster
    % clock, with increments of t_now_jump clocks between consecutive time
    % points
     
    t_now_vec = (domain.ms_start_sync + w*sync_int : 1e-6 : sync_int * size(domain.t_vec_ms,1))';    
    [tg] = Calc_tidg(t_now_vec, domain.follow_up_offest ,domain.t_vec_ms(:,4),  O_sr, F_sr, [], [], []);
    
    % plot error of t_g as calculated from Equation 7-10 vs. reference
    t = t_now_vec ./ domain.slave_params.inc ./ domain.slave_params.clk;
    tg_ref = t .* domain.grandmaster_params.inc .* domain.grandmaster_params.clk; % generate the grandmaster time stamp at the reference time points 
    figure; plot(t_now_vec, tg_ref-tg);
    xlabel('Time [Sec]');
    ylabel('timing error of slave vs. grandmaster [Sec]');
    grid on
    title(sprintf('intra domain %s t_g', domain.print_title));

    % plot time offset between slave and grandmaster as calculated from
    % Equation 7.9 vs. reference
    figure;
    t = domain.t_vec_ms(:, 4)/1e-9/domain.slave_params.inc/domain.slave_params.clk;
    O_sr_ref = -((t*domain.slave_params.clk)*domain.slave_params.inc*1e-9 - (t*domain.grandmaster_params.clk)*domain.grandmaster_params.inc*1e-9);
    plot(t,[O_sr-O_sr_ref]);
    grid on;
    xlabel('Time [Sec]');
    ylabel('Slave - Grandmaster timing offset [Sec]');
    title(sprintf('intra domain %s O(S%s,R%s)', domain.print_title,domain.print_title,domain.print_title));

    % plot frequency offset between slave and grandmaster as calculated from
    % Equation 7.4 vs. actual dppm offset
    figure;
    F_sr_ref = -domain.grandmaster_params.ppm + domain.slave_params.ppm;
    time_ax = (0:length(F_sr)-1)*sync_int;
    plot(time_ax,(F_sr/2^41)*1e6, time_ax, F_sr_ref*ones(size(time_ax)),'--')

    grid on
    xlabel('Time [Sec]');
    ylabel('Slave - Grandmaster Frequency offset [ppm]');
    title(sprintf('intra domain %s F(S%s,R%s)', domain.print_title,domain.print_title,domain.print_title));
    
    figure;
    F_mr_ref = -domain.grandmaster_params.ppm + domain.master_params.ppm;
    time_ax = (0:length(F_mr)-1)*sync_int;
    plot(time_ax,(F_mr/2^41)*1e6, time_ax, F_mr_ref*ones(size(time_ax)),'--');
    hold on
    plot(time_ax,(F_mr_original/2^41)*1e6);
    hold off
    
    grid on
    xlabel('Time [Sec]');
    ylabel('Master - Grandmaster Frequency offset [ppm]');
    title(sprintf('intra domain %s F(M%s,R%s)', domain.print_title,domain.print_title,domain.print_title));

end

