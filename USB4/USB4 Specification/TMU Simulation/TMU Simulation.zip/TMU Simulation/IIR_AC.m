% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

function [Y] = IIR_AC(X, p, filterStart, gradientVector, syncIntVec)
%   [Y] = IIR_AC(X, p, filterStart, gradientVector, syncIntVec)   
%     
% 
%   IIR filter with attenuation compensation for lineary increasing
%   functions: 
%   Y[n] = IIR(X[n],p) + IIR( X[n] - IIR(X[n],p) ,p)
% 
%  
%     Inputs:
%         X - Vector to be filtered.
%         p - IIR filter power (see IIR()).
%         filterStart - Index to start the filtering from. Used to start
%         filtering only after the input vector X is stable. filterStart =
%         [] will initiate a default value of 1.  
%         gradientVector - A vector of the estimated gradient of the input
%         for any given time (i.e. the difference between 2 consecutive
%         samples of X). Used for smart initialization of the filter state
%         in order to minimize initial error and convergence time). Only
%         gradientVector(filterStart) is actually used. gradientVector = []
%         will initiate a default gradient value of zero.
%         syncIntVec - A vector of the local time difference (or number of
%         samples difference) between each two consecutive entries in the
%         input vector X. Used to compensate for missing samples.
%         syncIntVec = [] will initiate a default vector of 1's (i.e. no
%         missing samples compensation).   
%
%     Outputs:
%         Y - Filtered vector.     


Y = zeros(size(X));

if isempty(filterStart)
    filterStart = 1;
else
    filterStart = filterStart(1);
end

if isempty(gradientVector)
    gradient = 0;
    gradientVector = zeros(size(X));
else
    gradient = gradientVector(filterStart);
end

if isempty(syncIntVec)
    syncIntVec = ones(size(X));
end

b = 1/2^p;
expectedOffset = ((b-1)./b).*gradient; % smart initialization such that the filter output error will start close to the steady state error.

missingSamples = round(syncIntVec./mean(syncIntVec(filterStart:end))) - 1; % missing samples compensation to stay close to the steady state.

X_filtered = IIR(X + (1 - b)./b.*(missingSamples).*gradientVector , p, filterStart, expectedOffset);

Error = X - X_filtered;
Error_filtered = IIR(Error, p, filterStart, []);

Y(1:filterStart) = X(1:filterStart);
Y(filterStart:end) = X_filtered(filterStart:end) + Error_filtered(filterStart:end);

end

