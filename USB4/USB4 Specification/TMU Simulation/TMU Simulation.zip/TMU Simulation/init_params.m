% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.



% general parameters

quantization.stamp_max_val = 2^64*1e-9; % max value of local time counter (Figure 7-3) in seconds.
quantization.stamp_num_bits = 80; % numbtmuer of bits of local time counter (Figure 7-3)
quantization.freq_off_max_val = 2^31; % max value of frequency offset (Figure 7-5)
quantization.freq_off_num_bits = 32; % number of bits of frequency offset (Figure 7-5)
quantization.time_offset_max_val = 2^47*1e-9; % max value of time offset (Figure 7-4) in seconds.
quantization.time_offset_num_bits = 64; % number of bits of time offset (Figure 7-4)
sim_time = 1; % total time of simulation in seconds.


w = 800; % Number of Time Sync Handshakes over which the frequency offset is computed
sync_int = 16e-6; % time between handshakes [seconds]
is_jitter_ref = 1; % is to add jitter to the reference clock in order to make a more realistic compare.

% time of first handshake for each pair of routers. In this simulation its
% assumed that the routers are connected by the following order:
% Rg - Rj 
id_gj_start_sync = 100e-6;
% Rj - Mj / Ri - Mi
rm_start_sync = 200e-6;
% Mj - Sj / Mi - Si
ms_start_sync = 300e-6; 
% Sj - Si
id_ji_start_sync = 400e-6;

num_of_handshakes = ceil(sim_time/16e-6/w)*w; % total number of simuated handshakes between each pair of adjacent units (each handshake as in Figure 7-7)

% Domain i parameters
domain_i.sm_pd = 3e-9; % master-slave propagation delay [Sec]
domain_i.rm_pd = 6e-9; % grandmaster-master propagation delay [Sec]
domain_i.t3_t2_int = 500e-9; % time at master port between first handshake message arrival (t2) to second message transmistion (t3) [S]. t3-t2 will be uniformly distributed between 0 and t3_t2_int
domain_i.pd_std = 1e-9; % standard deviation of random Gaussian noise added to the propagation delay [S]
domain_i.follow_up_offest = 1e-6; % delay at slave between handshake t4 until it can use the handshake results for calculating t_g or t_id_jig
domain_i.quantize_ref = 0; % if 1, slave compares t_g to the value calculated at its last clock edge, if 0 - it interpolates between clock edges


% IIR filters (Equation 7-18)
domain_i.filters.p_D = 10; %16;  % p parameter of the IIR filter for propagation delay smoothing  
domain_i.filters.p_F = 4; %6;    % p parameter of the IIR filter for frequency offset smoothing
domain_i.filters.p_T = 10; %16;  % p parameter of the IIR filter for time offset smoothing


% grandmaster clock prameters
domain_i.grandmaster_params.nominal_clk = 125e6; % grand master nominal clock [Hz]
domain_i.grandmaster_params.ppm = 67.567; %-30; % grand master clock ppm offset from nominal
domain_i.grandmaster_params.jitter = 1e-9; % clock jitter noise distributed uniformly with bias 0 in the inteval provided.
domain_i.grandmaster_params.inc = quant(1/domain_i.grandmaster_params.nominal_clk/1e-9, quantization.stamp_max_val, quantization.stamp_num_bits); % grand master local time counter increment (format of Figure 7-3)
domain_i.grandmaster_params.clk = domain_i.grandmaster_params.nominal_clk*(1+domain_i.grandmaster_params.ppm/1e6); % grand master actual clock [Hz]


% master clock prameters
domain_i.master_params.nominal_clk = 200e6; 
domain_i.master_params.ppm = -47; %67.567;
domain_i.master_params.jitter = 1e-9; % clock jitter noise.
domain_i.master_params.inc = quant(1/domain_i.master_params.nominal_clk/1e-9, quantization.stamp_max_val, quantization.stamp_num_bits);
domain_i.master_params.clk = domain_i.master_params.nominal_clk*(1+domain_i.master_params.ppm/1e6);


% slave clock prameters
domain_i.slave_params.nominal_clk = 125e6; 
domain_i.slave_params.ppm = 37.45;
domain_i.slave_params.jitter = 1e-9; % clock jitter noise.
domain_i.slave_params.inc = quant(1/domain_i.slave_params.nominal_clk/1e-9, quantization.stamp_max_val, quantization.stamp_num_bits);
domain_i.slave_params.clk = domain_i.slave_params.nominal_clk*(1+domain_i.slave_params.ppm/1e6);


domain_i.ms_start_sync = ceil(ms_start_sync/(domain_i.slave_params.inc/1e9))/domain_i.slave_params.clk;  % time of first master-slave handshake. Following the first, there will be another handshake every sync_int sec.
domain_i.rm_start_sync = ceil(rm_start_sync/(domain_i.master_params.inc/1e9))/domain_i.master_params.clk; % time of first grandmaster-master handshake. Following the first, there will be another handshake every sync_int sec.
if domain_i.ms_start_sync < domain_i.rm_start_sync  % it is assumed that the master and grandmaster sync before the master and slave sync, such that during master-slave sync the results of the master-grandmaster sync can already be used
    error('rm must sync first');
end
domain_i.print_on = 1;  % if 1, results of intra-domain calculations are plotted for domain i
domain_i.print_title = 'i';  % string used at plot titles


% domain j parameters  - same format as Domain i

domain_j.sm_pd = 100e-2/3e8;
domain_j.rm_pd = 200e-2/3e8;
domain_j.t3_t2_int = 500e-9; % [S]
domain_j.pd_std = 1e-9; % [S]
domain_j.follow_up_offest = 1e-6;
domain_j.quantize_ref = 0;

% IIR filters
domain_j.filters.p_D = 10; %16;
domain_j.filters.p_F = 4; %6;
domain_j.filters.p_T = 10; %16;

domain_j.grandmaster_params.nominal_clk = 200e6;
domain_j.grandmaster_params.ppm = -90; %-30;
domain_j.grandmaster_params.jitter = 1e-9; % clock jitter noise.
domain_j.grandmaster_params.inc = quant(1/domain_j.grandmaster_params.nominal_clk/1e-9, quantization.stamp_max_val, quantization.stamp_num_bits);
domain_j.grandmaster_params.clk = domain_j.grandmaster_params.nominal_clk*(1+domain_j.grandmaster_params.ppm/1e6);

domain_j.master_params.nominal_clk = 125e6;
domain_j.master_params.ppm = 76; %67.567;
domain_j.master_params.jitter = 1e-9; % clock jitter noise.
domain_j.master_params.inc = quant(1/domain_j.master_params.nominal_clk/1e-9, quantization.stamp_max_val, quantization.stamp_num_bits);
domain_j.master_params.clk = domain_j.master_params.nominal_clk*(1+domain_j.master_params.ppm/1e6);


domain_j.slave_params.nominal_clk = 200e6;
domain_j.slave_params.ppm = 10;
domain_j.slave_params.jitter = 1e-9; % clock jitter noise.
domain_j.slave_params.inc = quant(1/domain_j.slave_params.nominal_clk/1e-9, quantization.stamp_max_val, quantization.stamp_num_bits);
domain_j.slave_params.clk = domain_j.slave_params.nominal_clk*(1+domain_j.slave_params.ppm/1e6);


domain_j.ms_start_sync = ceil(ms_start_sync/(domain_j.slave_params.inc/1e9))/domain_j.slave_params.clk;
domain_j.rm_start_sync = ceil(rm_start_sync/(domain_j.master_params.inc/1e9))/domain_j.master_params.clk;
if domain_j.ms_start_sync < domain_j.rm_start_sync
    error('rm must sync first');
end

domain_j.print_on = 1;
domain_j.print_title = 'j';  


% inter domain params
% refers to the inter domain handshake process between slave of domain i
% and slave of domain j
% clock parameters are taken from domain i and domain j parameters, only handshake paramretesr are specified here 

id_ji.pd = 100e-2/3e8;
id_ji.t3_t2_int = 500e-9; %[S]
id_ji.pd_std = 1e-9; % [S]
id_ji.follow_up_offest = 1e-6;
id_ji.quantize_ref = 0;


% IIR filters
id_ji.filters.p_D = 10; %16;
id_ji.filters.p_F = 4; %6;
id_ji.filters.p_T = 10; %16;

id_ji.start_sync = ceil(id_ji_start_sync/(domain_i.slave_params.inc/1e9))/domain_i.slave_params.clk; % time of first inter domain handshake. Following the first, there will be another handshake every sync_int sec.
if id_ji.start_sync < domain_i.ms_start_sync || id_ji.start_sync < domain_j.ms_start_sync % it is assumed that inter domain sync takes place after the intra-domain handshakes, such that during inter domain sync the results of the intra domain syncs can already be used
    error('inter domain must sync after domains i and j');
end

% grandmaster - master inter domain
% refers to inter-domain handshake between grandmasters of domains j and g

id_gj.pd = 100e-2/3e8;
id_gj.t3_t2_int = 500e-9; %[S]
id_gj.pd_std = 1e-9; % [S]
id_gj.follow_up_offest = 1e-6;
id_gj.quantize_ref = 0;


% IIR filters
id_gj.filters.p_D = 10; %16;
id_gj.filters.p_F = 4; %6;
id_gj.filters.p_T = 10; %16;


domain_g.grandmaster_params.nominal_clk = 125e6;
domain_g.grandmaster_params.ppm = -50.567; %-30;
domain_g.grandmaster_params.jitter = 1e-9; % clock jitter noise.
domain_g.grandmaster_params.inc = quant(1/domain_g.grandmaster_params.nominal_clk/1e-9, quantization.stamp_max_val, quantization.stamp_num_bits);
domain_g.grandmaster_params.clk = domain_g.grandmaster_params.nominal_clk*(1+domain_g.grandmaster_params.ppm/1e6);



id_gj.start_sync = ceil(id_gj_start_sync/(domain_j.grandmaster_params.inc/1e9))/domain_j.grandmaster_params.clk; % time of first g-j grandmaster inter domain handshake. Following the first, there will be another handshake every sync_int sec.
if id_gj.start_sync > id_ji.start_sync % it is assumed that i-j inter domain sync takes place after the g-j inter domain sync, such that during i-j inter domain sync the results of the g-j inter domain syncs can already be used
    error('g to j must sync before inter domain');
end


