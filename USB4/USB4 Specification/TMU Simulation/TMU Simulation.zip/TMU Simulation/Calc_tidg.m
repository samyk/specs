% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

function [t_idg] = Calc_tidg(t_now_vec, min_buffer, t4_s_sm_intra, O_sRs, F_sRs, t_last_id_s, O_RsRg, F_RsRg)

%   [t_idg] = Calc_tidg(t_now_vec, follow_up_offest, t4_s_ms_intra, O_sRs, F_sRs, t_last_id_s, O_RgRs, F_RgRs)
%   
%   Equation 7-10 - Time at the Grandmaster.
%   Equation 7-17 - Time at the Inter-Domain Grandmaster.
%   Both equations are time at the Host Router of the Master Domain.
% 
%   Inputs:
%       t_now_vec- Vector of the time at the slave router to calculate the Grandmaster time for.
%       min_buffer- Extra buffer take into account a delay in availability.
%       
%       Slave router internal intra-domain registers (values that the slave
%       calculated/measured during previous intra-domain handshakes with
%       other routers, relevant only for inter-domain time sync):
%           t4_s_sm_intra- Slave time stamps vector, t_4, from its handshakes
%           acting as an intra-domain Slave.  
%           O_sRs- Slave time offsets vector, O(S,R), from its handshakes
%           acting as an intra-domain Slave.     
%           F_sRs- Slave frequency offsets vector, F(S,R), from its
%           handshakes acting as an intra-domain Slave.    
%	     
%       Slave router internal inter-domain registers (values that the slave
%       calculated/measured/recieved during previous inter-domain handshakes with
%       other routers, relevant only for equation 7-17):
%           t_last_id_s- Vector of inter-domain time stamps, t_last-id(S) of
%           equation 7.11, time at the Grandmaster router of the domain of 
%           the Slave router, at t_vec_ms(:,4) times (t4 of handshakes).
%           t_last_id_s = [] will initiate a default value of a zero vector.   
%           O_RsRg- Vector of time offsets, O(Rs,Rg), between Grandmaster
%           router of the domain of the Slave router, and the inter-domain
%           Grandmaster router. O_RsRg = [] will initiate a default value
%           of a zero vector.
%           F_RsRg- Vector of frequency offsets, F(Rs,Rg), between
%           Grandmaster router of the domain of the Slave router, and the 
%           inter-domain Grandmaster router. F_RsRg = [] will initiate a
%           default value of a zero vector.   
%
%   Output:
%       t_idg- Vector of the time at the Grandmaster clock as calculated by the Slave router
%       for t_now_vec times. If inter-domain registers are supplied the
%       time is at the Inter-domain Grandmaster clock.



    if isempty(t_last_id_s)
       t_last_id_s = zeros(size(t4_s_sm_intra,1),1);
    end

    if isempty(O_RsRg)
       O_RsRg = zeros(size(t4_s_sm_intra,1),1);
    end

    if isempty(F_RsRg)
       F_RsRg = zeros(size(t4_s_sm_intra,1),1);
    end
    
    last_sync = get_index_offset_for_t_vec_sync(t_now_vec, t4_s_sm_intra , min_buffer);
    
    t_idg = t_last_id_s(last_sync) + O_RsRg(last_sync) +( t4_s_sm_intra(last_sync) + O_sRs(last_sync) + ((t_now_vec -  t4_s_sm_intra(last_sync))./(1+F_sRs(last_sync)/2^41)) - t_last_id_s(last_sync))./(1+F_RsRg(last_sync)/2^41);
    
end
