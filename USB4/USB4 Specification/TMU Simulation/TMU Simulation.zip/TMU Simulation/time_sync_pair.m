% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


function [F_sr, O_sr, F_sm, O_sm, D_ms, t_last_id_s, O_RsRg, F_RsRg] = ...
    time_sync_pair(t_vec_ms, ...
    sync_int, w, filters, quantization,...
    t4_m_mr_intra, O_m_mr_intra, F_m_mr_intra, firstValid_F_m_mr_intra_Index,...
    t4_s_sm_intra, O_s_sr_intra, F_s_sr_intra, firstValid_F_s_sr_intra_Index,...
    t_last_id_m, O_RmRg, F_RmRg, firstValid_F_RmRg_Index)
% handshake process between 2 routers, denoted master - slave
% [F_sr, O_sr, F_sm, O_sm, D_ms, t_last_id_s, O_RsRg, F_RsRg] = ...
%     time_sync_pair(t_vec_ms, slave_inc, master_inc,...
%     sync_int, w, filters, quantization,...
%     t4_m_mr_intra, O_m_mr_intra, F_m_mr_intra, firstValid_F_m_mr_intra_Index,...
%     t4_s_sm_intra, O_s_sr_intra, F_s_sr_intra, firstValid_F_s_sr_intra_Index,...
%     t_last_id_m, O_RmRg, F_RmRg, firstValid_F_RmRg_Index)
%
%
% Expected inputs:
%
%     Handshake parameters:
%         t_vec_ms - Handshake time stamps matrix of the sync, each row is
%         (t1 t2 t3 t4), matrix dimensions are (number of handshakes)X(4).   
%         slave_inc - Slave time stamp nominal increment in nano seconds
%         per clock (e.g. 8 for 125MHz). 
%         master_inc - Master time stamp nominal increment in nano seconds
%         per clock (e.g. 8 for 125MHz). 
%         sync_int - Slave time increment in seconds between every two
%         slave-initiated handshakes. sync_int = [] will initiate a default
%         value mean(diff(t_vec_ms(:,1)).  
%         w - Number of handshakes between two consequitive frequency ratio
%         calculations. 
%
%     Simulation parameters:
%         filters- Filters' power parameters struct: 
%             .p_T- Power of time offset filtering.
%             .p_D- Power of propagation delay filtering.
%             .p_F- Power of frequency offset filtering.
%         quantization- Quantization parameters struct:
%             .stamp_max_val- max value of local time counter (Figure 7-3)
%             .stamp_num_bits- numbtmuer of bits of local time counter
%             (Figure 7-3) 
%             .freq_off_max_val- max value of frequency offset (Figure 7-5)
%             .freq_off_num_bits- number of bits of frequency offset
%             (Figure 7-5) 
%             .time_offset_max_val- max value of time offset (Figure 7-4)
%             .time_offset_num_bits- number of bits of time offset (Figure
%             7-4) 
%
%     Master router internal intra-domain registers (values that the master
%     calculated/measured during previous intra-domain handshakes with
%     other routers):  
%         t4_m_mr_intra- Master time stamps vector, t_4, from its
%         handshakes acting as Slave. t4_m_mr_intra = [] will initiate a
%         default value of a zero vector.  
%         O_m_mr_intra- Master time offsets vector, O(M,R), from its
%         handshakes acting as Slave. O_m_mr_intra = [] will initiate a
%         default value of a zero vector.  
%         F_m_mr_intra- Master frequency offsets vector, F(M,R), from its
%         handshakes acting as Slave. F_m_mr_intra = [] will initiate a
%         default value of a zero vector.  
%         firstValid_F_m_mr_intra_Index- Index into the vector F_m_mr_intra
%         of the first valid frequency offset value that can be used.
%         firstValid_F_m_mr_intra_Index = [] will initiate a default value
%         of 1
%         
%
%     Slave router internal intra-domain registers (values that the slave
%     calculated/measured during previous intra-domain handshakes with
%     other routers, relevant only for inter-domain time sync):  
%         t4_s_sm_intra- Slave time stamps vector, t_4, from its handshakes
%         acting as an intra-domain Slave. t4_m_ms_intra = [] will initiate
%         a default value of a zero vector.  
%         O_s_sr_intra- Slave time offsets vector, O(S,R), from its
%         handshakes acting as an intra-domain Slave. O_s_sr_intra = []
%         will initiate a default value of a zero vector.  
%         F_s_sr_intra- Slave frequency offsets vector, F(S,R), from its
%         handshakes acting as an intra-domain Slave. F_s_sr_intra = []
%         will initiate a default value of a zero vector.  
%         firstValid_F_s_sr_intra_Index- Index into the vector F_s_sr_intra
%         of the first valid frequency offset value that can be used.
%         firstValid_F_s_sr_intra_Index = [] will initiate a default value
%         of 1.
%
%     Master router internal inter-domain registers (values that the master
%     calculated/measured during previous inter-domain handshakes, or
%     received during previous intra-domain handshakes, with other routers,
%     relevant only for inter-domain time sync):   
%         t_last_id_m- t_last_id vector in the domain of the Master router,
%         t_last-id(M) of equation 7.16, time of the intra-domain
%         Grandmaster router of the domain of the Master router at the time
%         when the inter-domain parameters at the Master router were
%         calculated.    
%         O_RmRg- Time offsets vector, O(Rm,Rg), between the intra-domain
%         Grandmaster router of the domain of the Master router, and the
%         inter-domain Grandmaster router.  
%         F_RmRg- Frquency offsets vector, F(Rm,Rg), between the
%         intra-domain Grandmaster router of the domain of the Master
%         router, and the inter-domain Grandmaster router.  
%         firstValid_F_RmRg_Index- Index into the vector F_RmRg
%         of the first valid frequency offset value that can be used.
%         firstValid_F_RmRg_Index = [] will initiate a default value
%         of 1
%         
%
% Returned values:
%
%     Intra-domain variables needed to calculate Tg of equation 7-10, and
%     also for future followup messages (or Inter-domain intermidiate
%     calculations). For example, if the current slave will be a master in
%     the future, he will send these in the follow up message.   
%         F_sr- Vector of frequency offsets, F(S,R), between Slave router
%         and Grandmaster router of the domain of the Master router.  
%         O_sr- Vector of time offsets, O(S,R), between Slave router and
%         Grandmaster router of the domain of the Master router.  
%
%     Intra-domain/Inter-domain intermidiate calculations:
%         F_sm- Vector of frequency offsets, F(S,M), between Slave router
%         and Master router. 
%         O_sm- Vector of time offsets, O(S,M), between Slave router and
%         Master router. 
%         D_ms- Vector of propagation delays D(S,M) between Slave router
%         and Master router. (Bi-Directional only) 
%
%     Inter-domain variables needed to calculate Tidg of equation 7-17, and
%     also for future followup messages (inter-domain only): 
%         t_last_id_s- Vector of inter-domain time stamps, t_last-id(S) of
%         equation 7.11, time at the Grandmaster router of the domain of
%         the Slave router, at t_vec_ms(:,4) times (t4 of handshakes).  
%         O_RsRg- Vector of time offsets, O(Rs,Rg), between Grandmaster
%         router of the domain of the Slave router, and the inter-domain
%         Grandmaster router.  
%         F_RsRg- Vector of frequency offsets, F(Rs,Rg), between
%         Grandmaster router of the domain of the Slave router, and the
%         inter-domain Grandmaster router.  

if isempty(t4_m_mr_intra)
   t4_m_mr_intra = zeros(size(t_vec_ms,1),1);
end

if isempty(O_m_mr_intra)
   O_m_mr_intra = zeros(size(t_vec_ms,1),1);
end

if isempty(F_m_mr_intra)
   F_m_mr_intra = zeros(size(t_vec_ms,1),1);
end

if isempty(firstValid_F_m_mr_intra_Index)
   firstValid_F_m_mr_intra_Index = 1;
end

if isempty(t4_s_sm_intra)
   t4_s_sm_intra = zeros(size(t_vec_ms,1),1);
end

if isempty(O_s_sr_intra)
   O_s_sr_intra = zeros(size(t_vec_ms,1),1);
end

if isempty(F_s_sr_intra)
   F_s_sr_intra = zeros(size(t_vec_ms,1),1);
end

if isempty(firstValid_F_s_sr_intra_Index)
   firstValid_F_s_sr_intra_Index = 1;
end

if isempty(t_last_id_m)
   t_last_id_m = zeros(size(t_vec_ms,1),1);
end

if isempty(O_RmRg)
   O_RmRg = zeros(size(t_vec_ms,1),1);
end

if isempty(F_RmRg)
   F_RmRg = zeros(size(t_vec_ms,1),1);
end

if isempty(firstValid_F_RmRg_Index)
   firstValid_F_RmRg_Index = 1;
end

acctual_sync_int = [0; diff(t_vec_ms(:,1))];

% Equation 7-1: Frequency Ratio between Slave and Master
f_vec_decimated = [ ones(1,size(t_vec_ms,2)); diff(t_vec_ms(1:w:end, :)) ]; % dilute handshakes by w
f_sm_decimated = f_vec_decimated(:, 4)./f_vec_decimated(:, 3);


% Equation 7-2. Frequency Offset between Slave and Master
F_sm_decimated = freq_ratio_to_freq_offset(f_sm_decimated, []);

% Equation 7-18. IIR Low Pass Filter.
% In order to reduce convergence time and initial error, the
% filtering starts only after F_sm is calculated for the first time (index 2 in the frequency offset vector since index 1 is dummy).
F_sm_decimated_filt = IIR(F_sm_decimated, filters.p_F, 2, []);
F_sm_diluted = reshape(repmat(F_sm_decimated_filt.', w, 1),[],1); % expand the decimated frequency offset vector to have an entry per handshake
F_sm = F_sm_diluted(1:size(t_vec_ms,1)); % discard extra values

% Equation 7-3. Frequency Ratio between Slave and Grandmaster
f_mr = freq_offset_to_freq_ratio(F_m_mr_intra);
f_sm = freq_offset_to_freq_ratio(F_sm); 
f_sr =  f_sm .* f_mr;

% Equation 7-4. Frequency Offset between Slave and Grandmaster
F_sr = freq_ratio_to_freq_offset(f_sr, quantization);

% Equation 7-5: Propagation Delay (Bi-Directional Mode only). Additional
% offset term to compensate for the quantizaion of t2 and t4 when sampled
% at the master and slave clocks, respectively
D_ms_nonfilt = ((t_vec_ms(:, 4) - t_vec_ms(:, 1)) - (t_vec_ms(:, 3) - t_vec_ms(:, 2)))/2;  

% Equation 7-18. IIR Low Pass Filter
D_ms = IIR(D_ms_nonfilt, filters.p_D, [], []);

% Equation 7-7: Time Offset from Master in Bi-Directional Mode
O_sm_non_filt_before_quant =  t_vec_ms(:, 3) - t_vec_ms(:, 4) + D_ms_nonfilt; 
O_sm_non_filt = quant (O_sm_non_filt_before_quant, quantization.time_offset_max_val, quantization.time_offset_num_bits);


% Equation 7-18 - IIR Low Pass Filter with attenuation compensation. See
% chapter 7.4.3. In order to reduce convergence time and initial error the
% filter is set to begin only after w+1 handshakes, when the first valid
% F_sm is available.
f_ms = 1./f_sm;
O_sm_before_quant = IIR_AC(O_sm_non_filt, filters.p_T, w + 1, sync_int .* (f_ms-1), acctual_sync_int);
O_sm = quant (O_sm_before_quant, quantization.time_offset_max_val, quantization.time_offset_num_bits);

% Equation 7-6. Time Offset that Master Sends in Follow-Up Packet.
% Equation 7-14. Time Offset from the Inter-Domain Master
% Both equations are Time Offset between the Master and Host Router of the Master Domain.
% it is assumed that this value is not filtered at the master.
f_rm = 1./f_mr; % It is more convenienct to use the reciprocal ratio for calculations
O_rm_at_t3_non_filt_before_quant = O_m_mr_intra + (t_vec_ms(:,3)-t4_m_mr_intra).*(f_rm-1);
O_rm_at_t3_non_filt = quant (O_rm_at_t3_non_filt_before_quant, quantization.time_offset_max_val, quantization.time_offset_num_bits);


% Equation 7-9 - Time Offset from Grandmaster
% Equation 7-15 - Time Offset between the Inter-Domain Slave and Host Router of the Master Domain
% Both equations are Time Offset between the Slave and Host Router of the Master Domain.
O_sr_non_filt_before_quant = O_rm_at_t3_non_filt + O_sm_non_filt; 
O_sr_non_filt = quant (O_sr_non_filt_before_quant, quantization.time_offset_max_val, quantization.time_offset_num_bits);

% Equation 7-18 - IIR Low Pass Filter with attenuation compensation. See
% chapter 7.4.3. The filter starts working after all the relevant routers
% already calculated their frequency offset at least once
f_rs = 1./f_sr;
O_sr_before_quant = IIR_AC(O_sr_non_filt, filters.p_T, max(firstValid_F_m_mr_intra_Index, w + 1), sync_int.*(f_rs-1), acctual_sync_int);
O_sr = quant (O_sr_before_quant, quantization.time_offset_max_val, quantization.time_offset_num_bits);


%% This is relevant only if it is an inter domain handshake

% Inverse Equation 7-2. frequency ratio from frequency offset
f_s_rs_intra = 1./freq_offset_to_freq_ratio(F_s_sr_intra);
f_s_sr_intra = 1./f_s_rs_intra;
f_RgRm = 1./freq_offset_to_freq_ratio(F_RmRg);
f_RmRg = 1./f_RgRm;

% Equation 7-12. Frequency Ratio between Host Router of the Slave Domain and Host Router of the Grandmaster Domain
% note that f_rs is already f_rm .* f_ms.
f_RgRs =  f_RgRm .* f_rs ./ f_s_rs_intra; % This is the reciprocal of the value defined in the spec, more convenient for calculations
f_RsRg =  f_RmRg .* f_sr ./ f_s_sr_intra; % this is the value defined in the spec

% Equation 7-13. Frequency Offset of Inter-Domain from Inter-Domain Grandmaster
F_RsRg = freq_ratio_to_freq_offset(f_RsRg, quantization);

% Equation 7-11. Inter-Domain Time Stamp
t_last_id_s = t4_s_sm_intra + O_s_sr_intra + (t_vec_ms(:,4) - t4_s_sm_intra).*(f_s_rs_intra);

% Equation 7-16. Time Offset between the Host Router of the Slave Domain and the Host Router of the Grandmaster Domain
O_RsRg_nonfilt_before_quant = O_sr_non_filt + O_RmRg  - O_s_sr_intra - (t_vec_ms(:,4) - t4_s_sm_intra).*(f_s_rs_intra-1) + ((t_vec_ms(:,4) + O_sr) - (t_last_id_m)).*(f_RgRm-1);
O_RsRg_nonfilt = quant (O_RsRg_nonfilt_before_quant, quantization.time_offset_max_val, quantization.time_offset_num_bits);

% Equation 7-18 - IIR Low Pass Filter with attenuation compensation. See
% chapter 7.4.3. The filter starts working after all the relevant routers
% already calculated their frequency offset at least once
O_RsRg_before_quant = IIR_AC(O_RsRg_nonfilt, filters.p_T, max([firstValid_F_RmRg_Index,firstValid_F_m_mr_intra_Index, w + 1, firstValid_F_s_sr_intra_Index]), sync_int .* (f_RgRs-1), acctual_sync_int);
O_RsRg = quant (O_RsRg_before_quant, quantization.time_offset_max_val, quantization.time_offset_num_bits);




