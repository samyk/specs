% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


% The model simulates the following network architecture
% 
%                    +                    +
%                    |                    |
%      Domain g      |      Domain j      |      Domain i
% Grandmaster domain |                    |
%                    |                    |
%     +--------+     |     +--------+     |     +--------+
%     |        |     |     |        |     |     |        |
%     |   Rg   +<--------->+   Rj   |     |     |   Ri   |
%     |        |IDM  |  IDS|        |     |     |        |
%     +--------+     |     +---+----+     |     +---+----+
%                    |         ^ M        |         ^ M
%                    |         |          |         |
%                    |         |          |         |
%                    |         v S        |         v S
%                    |     +---+----+     |     +---+----+
%                    |     |        |     |     |        |
%                    |     |   Mj   |     |     |   Mi   |
%                    |     |        |     |     |        |
%                    |     +---+----+     |     +---+----+
%                    |         ^ M        |         ^ M
%                    |         |          |         |
%                    |         |          |         |
%                    |         v S        |         v S
%                    |     +---+----+     |     +---+----+
%                    |     |        |     |     |        |
%                    |     |   Sj   +<--------->+   Si   |
%                    |     |        |IDM  |  IDS|        |
%                    |     +--------+     |     +--------+
%                    |                    |
%                    +                    +
% 

close all;
%clear all;
% set simulation parameters
init_params;

% Create all t1,t2,t3,t4 values for all handshakes in the network
% For each handshake between a pair of routers, we generate a matrix
% The number of rows is the number of handshakes, each row contains
% t1,t2,t3,t4
% This enables to run the simulation in a vectorized manner
% All the handshake matrices are asynchronous to one another, so later the matrices will be aligned such that the same row in all matrices
% should be processed together
% In case the t1,t2,t3,t4 values should be loaded from an external source
% (e.g. measured from hardware), the proper matrix should be overriden

% Inter domain handshakes between Si and Sj
[t_vec_id_ji, q_id_ji] = handshake(num_of_handshakes, domain_i.slave_params.clk, domain_i.slave_params.inc, domain_i.slave_params.jitter, id_ji.pd, id_ji.pd_std, domain_j.slave_params.clk, domain_j.slave_params.inc, domain_j.slave_params.jitter, id_ji.t3_t2_int, id_ji.start_sync, sync_int);
% Inter domain handshakes between Rj and Rg
[t_vec_id_gj, q_id_gj] = handshake(num_of_handshakes, domain_j.grandmaster_params.clk, domain_j.grandmaster_params.inc, domain_j.grandmaster_params.jitter, id_gj.pd, id_gj.pd_std, domain_g.grandmaster_params.clk, domain_g.grandmaster_params.inc, domain_g.grandmaster_params.jitter, id_gj.t3_t2_int, id_gj.start_sync, sync_int);
% Intra domain handshakes between Si and Mi
[domain_i.t_vec_ms, q_domain_i_ms] = handshake(num_of_handshakes, domain_i.slave_params.clk, domain_i.slave_params.inc, domain_i.slave_params.jitter, domain_i.sm_pd, domain_i.pd_std, domain_i.master_params.clk, domain_i.master_params.inc, domain_i.master_params.jitter, domain_i.t3_t2_int, domain_i.ms_start_sync, sync_int);
% Intra domain handshakes between Mi and Ri
[domain_i.t_vec_rm, q_domain_i_rm] = handshake(num_of_handshakes, domain_i.master_params.clk, domain_i.master_params.inc, domain_i.master_params.jitter, domain_i.rm_pd, domain_i.pd_std, domain_i.grandmaster_params.clk, domain_i.grandmaster_params.inc, domain_i.grandmaster_params.jitter, domain_i.t3_t2_int, domain_i.rm_start_sync, sync_int);
% Intra domain handshakes between Sj and Mj
[domain_j.t_vec_ms, q_domain_j_ms] = handshake(num_of_handshakes, domain_j.slave_params.clk, domain_j.slave_params.inc, domain_j.slave_params.jitter, domain_j.sm_pd, domain_j.pd_std, domain_j.master_params.clk, domain_j.master_params.inc, domain_j.master_params.jitter, domain_j.t3_t2_int, domain_j.ms_start_sync, sync_int);
% Intra domain handshakes between Mj and Rj
[domain_j.t_vec_rm, q_domain_j_rm] = handshake(num_of_handshakes, domain_j.master_params.clk, domain_j.master_params.inc, domain_j.master_params.jitter, domain_j.rm_pd, domain_j.pd_std, domain_j.grandmaster_params.clk, domain_j.grandmaster_params.inc, domain_j.grandmaster_params.jitter, domain_j.t3_t2_int, domain_j.rm_start_sync, sync_int);


% In order to make the simulation modular we have written here an exit/entrance point. 
% In this point all of the handshakes time have been generated but non of the time sync calculations have been made.
% The exit is made by writing time vectors data to CSV-type files.
% The entrance is being made by reading similarly made such CSV-type files.
% By default, this simulation writes out the time vectors created by the handshakes above to CSV-type files and then reads the files back. 
% This is done as an example of how this mechanism may be used.


% Write time vectors data to CSV-type files.
% This feature may be useful if you want to export the time vectors data for 
% an external application.

% create a cell array for each time vector, which contains time vector and file
% path couples.

cell_sj_si = {t_vec_id_ji, "csv_files/t_vec_id_ji.csv"};
cell_rg_rj = {t_vec_id_gj, "csv_files/t_vec_id_gj.csv"};
cell_i_ms = {domain_i.t_vec_ms, "csv_files/domain_i_t_vec_ms.csv"};
cell_i_rm = {domain_i.t_vec_rm, "csv_files/domain_i_t_vec_rm.csv"};
cell_j_ms = {domain_j.t_vec_ms, "csv_files/domain_j_t_vec_ms.csv"};
cell_j_rm = {domain_j.t_vec_rm, "csv_files/domain_j_t_vec_rm.csv"};

%call "write_csv_file" function for each cell array.
cellfun(@write_csv_file, {cell_sj_si, cell_rg_rj, cell_i_ms, cell_i_rm, cell_j_ms, cell_j_rm});


% Read time vectors data from CSV-type files.
% This feature may be useful if you want to import time vectors data from
% an external application or hardware.

% Define the path for each CSV-type file input.
path_sj_si = 'csv_files/t_vec_id_ji.csv';
path_rg_rj = 'csv_files/t_vec_id_gj.csv';
path_i_ms = 'csv_files/domain_i_t_vec_ms.csv';
path_i_rm = 'csv_files/domain_i_t_vec_rm.csv';
path_j_ms = 'csv_files/domain_j_t_vec_ms.csv';
path_j_rm = 'csv_files/domain_j_t_vec_rm.csv';

%call "read_csv_file" function for each csv file.
t_vecs_read = cellfun(@read_csv_file, {path_sj_si, path_rg_rj, path_i_ms, path_i_rm, path_j_ms, path_j_rm}, 'UniformOutput', false);
[t_vec_id_ji, t_vec_id_gj, domain_i.t_vec_ms, domain_i.t_vec_rm, domain_j.t_vec_ms, domain_j.t_vec_rm] = t_vecs_read{:};


% There are 2 functions for processing the handshake results
% time_sync_pair - processes the handshake between 2 routers (master &
% slave)
% time_sync_domain - processes the handshake of a domain with 3 routers (grandmaster, master &
% slave)


% Process handshakes of domain j

[domain_j_F_sr, domain_j_O_sr, domain_j_F_mr, domain_j_O_mr] = time_sync_domain(domain_j, w, sync_int, quantization);

% Process handshakes of domain i
[domain_i_F_sr, domain_i_O_sr, domain_i_F_mr, domain_i_O_mr] = time_sync_domain(domain_i, w, sync_int, quantization);

% Process inter domain handshakes (j <--> g) between Rj and Rg
[F_RgRj_rs, O_RgRj_rs, F_RgRj_ms, O_RgRj_ms, D_RgRj_ms, t_last_id_j, O_RgRj, F_RgRj] = ...
    time_sync_pair(t_vec_id_gj, ...
    sync_int ,w, id_gj.filters, quantization,...
    [], [], [], [],...  %Master is Rg host alone in its domain.
    [], [], [], [],...  %Slave is Rj host of its domain.
    [], [], [], []);    %Rg is interdomain Grandmaster so no "Upper" domain offsets is required

% When processing the handshake matrix between 2 routers, it is required that the
% handshake results matrices of other pairs will be aligned to this matrix
% It means that for every row containing a t1, t2, t3, t4 tuple, the
% approriate row in the other matrices will be the one that can be used for
% the calculations of the equations in the spec
% in other words, the appropriate row in the other matrices
% whould correspond to the latest available handshake 
% the function get_index_offset_for_t_vec_sync is used to generate an index
% vector for this alignment

% Alignment of all handshakes for the j<--->i inter domain time sync:

% Alignment of Si<-->Mi to Si<-->Sj
[index_id_ji_i_ms, ~] = get_index_offset_for_t_vec_sync(t_vec_id_ji(:,4),domain_i.t_vec_ms(:,4),domain_i.follow_up_offest);
% Alignment of Sj<-->Mj to Si<-->Sj
[index_id_ji_j_ms, ~] = get_index_offset_for_t_vec_sync(t_vec_id_ji(:,3),domain_j.t_vec_ms(:,4),domain_j.follow_up_offest);
% Alignment of Mj<-->Rj to Sj<-->Mj
[~, offset_index_j_ms_j_rm] = get_index_offset_for_t_vec_sync(domain_j.t_vec_ms(:,3),domain_j.t_vec_rm(:,4),domain_j.follow_up_offest);
% Alignment of Rj<-->Rg to Mj<-->Rj
[~, offset_index_j_rm_id_gj] = get_index_offset_for_t_vec_sync(domain_j.t_vec_rm(:,3),t_vec_id_gj(:,4),domain_j.follow_up_offest);
% Alignment of Rj<-->Rg to Si<-->Sj by adding the 3 indices corresponding
% to: Sj<-->Mj to Si<-->Sj, Mj<-->Rj to Sj<-->Mj, Rj<-->Rg to Mj<-->Rj
index_router_propagation_offset = min(max(index_id_ji_j_ms + offset_index_j_ms_j_rm + offset_index_j_rm_id_gj,1),length(domain_j.t_vec_ms(:,4)));

% Process inter domain handshakes (i <--> j) between Si and Sj
[F_RjSi, O_RjSi, F_SjSi, O_SjSi, D_SjSi, t_last_id_i, O_RgRi, F_RgRi] = ...
    time_sync_pair(t_vec_id_ji, ...
    sync_int, w, id_ji.filters, quantization,...
    domain_j.t_vec_ms(index_id_ji_j_ms,4), domain_j_O_sr(index_id_ji_j_ms), domain_j_F_sr(index_id_ji_j_ms), find(index_id_ji_j_ms >= w + 1, 1), ... 
    domain_i.t_vec_ms(index_id_ji_i_ms,4), domain_i_O_sr(index_id_ji_i_ms), domain_i_F_sr(index_id_ji_i_ms), find(index_id_ji_i_ms >= w + 1, 1), ...
    t_last_id_j(index_router_propagation_offset), O_RgRj(index_router_propagation_offset), F_RgRj(index_router_propagation_offset), find(index_router_propagation_offset >= w + 1, 1));

%%

% calculate grandmaster time stamp at slave and compare to reference

% generate a vector t_now_vec of time points at which the comparison to the reference
% will be done
% The reference time points are synced to the edges of the grandmaster
% clock, with increments of t_now_jump clocks between consecutive time
% points
t_now_vec = (id_ji.start_sync + w * sync_int : 1e-6 : sync_int * size(t_vec_id_ji,1))';    
[t_id_jig] = Calc_tidg(t_now_vec, domain_i.follow_up_offest ,domain_i.t_vec_ms(index_id_ji_i_ms,4),  domain_i_O_sr(index_id_ji_i_ms), domain_i_F_sr(index_id_ji_i_ms), t_last_id_i, O_RgRi, F_RgRi);

% plot error of t_id_jig as calculated from Equation 7-17 vs. reference
t = (t_now_vec) ./ domain_i.slave_params.clk  ./  domain_i.slave_params.inc;
t_idg_ref = (t) .* domain_g.grandmaster_params.clk  .*  domain_g.grandmaster_params.inc;
if is_jitter_ref
    t_idg_ref = t_idg_ref + domain_g.grandmaster_params.jitter .* (rand(size(t_idg_ref)) - 0.5);
end
figure; plot(t_now_vec, t_idg_ref-t_id_jig);
xlabel('Time [Sec]');
ylabel('timing error of domain i slave vs. domain g grandmaster [Sec]');
grid on
title('inter domain t_{idg}');


% plot time offset between slave i and grandmaster j as calculated from
% Equation 7.15 vs. reference
figure;
t = t_vec_id_ji(:, 4)/1e-9/domain_i.slave_params.inc/domain_i.slave_params.clk;
O_RjSi_ref = -((t*domain_i.slave_params.clk)*domain_i.slave_params.inc*1e-9 - (t*domain_j.grandmaster_params.clk)*domain_j.grandmaster_params.inc*1e-9);
plot((0:num_of_handshakes-1)*sync_int, O_RjSi-O_RjSi_ref)
grid on
xlabel('Time [Sec]');
ylabel('Slave - Grandmaster timing offset error [Sec]');
title('inter domain O(Si,Rj)');

% plot time offset between grandmaster i and grandmaster g as calculated from
% Equation 7.16 vs. reference
figure;
t = t_vec_id_ji(:, 4)/1e-9/domain_i.slave_params.inc/domain_i.slave_params.clk;
O_RgRi_ref = -((t*domain_i.grandmaster_params.clk)*domain_i.grandmaster_params.inc*1e-9 - (t*domain_g.grandmaster_params.clk)*domain_g.grandmaster_params.inc*1e-9);
plot((0:num_of_handshakes-1)*sync_int,[O_RgRi-O_RgRi_ref])
grid on
xlabel('Time [Sec]');
ylabel('Slave - Grandmaster timing offset error [Sec]');
title('inter domain O(Ri,Rg)');

% plot time offset between grandmaster i and grandmaster g as calculated from
% Equation 7-11: inter domain time stamp calculated at Sj (for id_ji hanshake ) vs. reference
figure;
t = t_vec_id_ji(:, 4)/1e-9/domain_i.slave_params.inc/domain_i.slave_params.clk;
t_last_id_i_ref = ((t*domain_i.grandmaster_params.clk)*domain_i.grandmaster_params.inc*1e-9);
plot((0:num_of_handshakes-1)*sync_int,[t_last_id_i-t_last_id_i_ref])
grid on
xlabel('Time [Sec]');
ylabel('Slave - Grandmaster time error [Sec]');
title('inter domain t-last-id_ji(Si)');

% plot frequency offset between grandmaster i and grandmaster g as calculated from
% Equation 7.13 vs. actual dppm offset
figure;
F_RgRi_ref = domain_i.grandmaster_params.ppm - domain_g.grandmaster_params.ppm;
time_ax = (0:length(F_RgRi)-1)*sync_int*w;
plot(time_ax,(F_RgRi/2^41)*1e6, time_ax, F_RgRi_ref*ones(size(time_ax)),'--')
grid on
xlabel('Time [Sec]');
ylabel('Slave - Grandmaster g vs. i Frequency offset [ppm]');
title('inter domain F(Ri,Rg)');


%% Release all data


%% input follow up fifo
Output = 0;
% t1_id_ji
% t2_id_ji
% t3_id_ji
% t4_id_ji
% O(M,Rm)@t3 - O(Sj,Rj) - domain_j_O_sr with offset
% F(M,Rm) -  domain_j_F_sr_full with offset
% t_last_id_ji(M) - t_last_id_ji(Sj) - t4_id_gj with offset
% O(Rm,Rg) - O_id_gj with offset
% F(Rm,Rg) - F_id_gj_full with offset
if (Output)
id_jiS_FU_FIFO = [t_vec_id_ji , domain_j_O_sr(index_id_ji_j_ms), domain_j_F_sr_full(index_id_ji_j_ms), t_vec_id_gj(index_router_propagation_offset,4), O_id_gj(index_router_propagation_offset), F_id_gj_full(index_router_propagation_offset)];

cHeader = {'t1' 't2' 't3' 't4' 'O(M_Rm)@t3' 'F(M_Rm)' 't_last_id_ji(M)' 'O(Rm_Rg)' 'F(Rm_Rg)'}; %header
commaHeader = [cHeader;repmat({','},1,numel(cHeader))]; %insert commaas
commaHeader = commaHeader(:)';
textHeader = cell2mat(commaHeader); %cHeader in text with commas
%write header to file
csvFileName = 'id_jiS_FU_FIFO.csv';
fid_ji = fopen(csvFileName,'w'); 
fprintf(fid_ji,'%s\n',textHeader);
fclose(fid_ji);
%write data to end of file
if (Output)
    dlmwrite(csvFileName,id_jiS_FU_FIFO,'-append','precision','%16.16f');
end
%% output calculations need for t_id_jig

% t_last_id_ji(S) - t_vec_id_ji(:,4)
% O(Rs,Rg) - O(Si,Rg)
% F(Rs,Rg) - F(Si,Rg)

O_si_rg = O_RjSi(:) + O_id_gj(index_router_propagation_offset) ...
    - (t_vec_id_ji(:, 4) - t_vec_id_gj(index_router_propagation_offset,4)... 
    + O_RjSi(:)).*F_id_gj_full(index_router_propagation_offset)./(2^41+F_id_gj_full(index_router_propagation_offset)); 

% Equation 7-12: Frequency Ratio between Host Router of the Slave Domain and Host Router of the Grandmaster Domain
f_Si_Rg_full = (1+F_id_ji_full/2^41).*domain_j_f_sr_full(index_id_ji_j_ms).*(1+F_id_gj_full(index_router_propagation_offset)/2^41);
f_Si_Rg = f_Si_Rg_full(1:w:end);

% Apply IIR filter to the Ri to Rg frequency offset 
F_Si_Rg_filt = filter(id_ji.filters.b_F, id_ji.filters.a_F, f_Si_Rg-1);
% quantize frequency offset to the format of Figure 7.5 (Equation 7.13)
F_Si_Rg = quant(F_Si_Rg_filt*2^41, quantization.freq_off_max_val, quantization.freq_off_num_bits);

% prepare a vector with most updated Ri-Rg frequency offset per each
% handshake
F_Si_Rg_rep = repmat(F_Si_Rg.', w, 1);
F_Si_Rg_full = F_Si_Rg_rep(:);

id_jiS_CALCULATED = [t_vec_id_ji(:,4), O_si_rg, F_Si_Rg_full];

cHeader = {'t_last_id_ji(S)' 'O(Rs_Rg)' 'F(Rs_Rg)'}; %header
commaHeader = [cHeader;repmat({','},1,numel(cHeader))]; %insert commaas
commaHeader = commaHeader(:)';
textHeader = cell2mat(commaHeader); %cHeader in text with commas
%write header to file
csvFileName = 'id_jiS_CALCULATED.csv';
fid_ji = fopen(csvFileName,'w'); 
fprintf(fid_ji,'%s\n',textHeader);
fclose(fid_ji);
%write data to end of file
if (Output)
    dlmwrite(csvFileName,id_jiS_CALCULATED,'-append','precision','%16.16f');
end
end