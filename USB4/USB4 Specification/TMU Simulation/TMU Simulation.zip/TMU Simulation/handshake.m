% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

function [t_vec, q] = handshake(num_of_handshakes, s_clk, s_inc, s_jit, sm_pd, sm_pd_std, m_clk, m_inc, m_jit, t3_t2_int, start_sync, sync_int) 
% simulate handshake process of Figure 7-7
    t_vec = zeros(num_of_handshakes, 4);
    q = zeros(num_of_handshakes, 2);
    s_Rx_time_to_wire =  s_inc*1e-9/2;  % quantization of arrival time to the nearest clock edge at the receive side results in constant offset of half the cclock period - slave side
    m_Rx_time_to_wire =  m_inc*1e-9/2;  % quantization of arrival time to the nearest clock edge at the receive side results in constant offset of half the cclock period - master side
    
    sync_int = ceil(sync_int * s_clk) * s_inc * 1e-9; % % time between handshakes, quantized to slave clocks
    
    for hs = 1:num_of_handshakes

        handshake_time = hs*sync_int + start_sync + 1e-6*randn; % time of handshake start (random jitter added to nominal time)  
    % find slave clock edge closest to sync start time
        t_start1_clks = ceil(handshake_time*s_clk);
    % translate clock edge to actual time
        t_start1 = t_start1_clks/s_clk;
    % find slave time stamp t1 at request transmission time
        t1 = t_start1_clks*s_inc*1e-9;

    % request packet arrives to master after propagation delay of sm_pd + random
    % Gaussian jitter with standard deviation sm_pd_std, and detected at the
    % first master clock edge after arrival
        t_arrive1_clks = ceil((t_start1 + sm_pd + sm_pd_std*randn + s_jit*(rand-0.5) + m_jit*(rand-0.5))*m_clk);
    % translate clock edge to actual time
        t_arrive1 = t_arrive1_clks/m_clk;
    % calculate quantization error due to detecting the packet at a master
    % clock edge
        q1 = t_arrive1 - (t_start1 + sm_pd);
    % find master time stamp t2 at reception time
        t2 = t_arrive1_clks*m_inc*1e-9 - m_Rx_time_to_wire; %time to wire

    % master transmits response after a delay, assumed uniformly distributed in
    % [0, t3_t2_int], and synchronized to the next master clock edge
        t_start2_clks = ceil((t_arrive1 + t3_t2_int*rand)*m_clk);
    % translate master clock edge to time
        t_start2 = t_start2_clks/m_clk;
    % find master time stamp t3 at transmission time
        t3 = t_start2_clks*m_inc*1e-9;


    % response packet arrives to slave after propagation delay of sm_pd +
    % random Gaussian jitter with standard deviation sm_pd_std, and detected at the
    % first slave clock edge after arrival 
        t_arrive2_clks = ceil((t_start2 + sm_pd + sm_pd_std*randn + s_jit *(rand-0.5) + m_jit*(rand-0.5))*s_clk);
    % translate clock edge to actual time
        t_arrive2 = t_arrive2_clks/s_clk;
    % calculate quantization error due to detecting the packet at a slave
    % clock edge
        q2 = t_arrive2 - (t_start2 + sm_pd);
    % find slave time stamp t4 at reception time
        t4 = t_arrive2_clks*s_inc*1e-9 - s_Rx_time_to_wire;

        t_vec(hs, :) = [t1 t2 t3 t4];
        q(hs, :) = [q1 q2];

    end
end

