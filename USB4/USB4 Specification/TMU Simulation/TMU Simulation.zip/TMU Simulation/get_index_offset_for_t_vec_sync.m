% Simulation of the TMU 
%
% Copyright 2019 Apple Inc.
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice,
% this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright
% notice, this list of conditions and the following disclaimer in the
% documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its
% contributors may be used to endorse or promote products derived from this
% software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

function [early_time_index, index_offset] = get_index_offset_for_t_vec_sync(target_time_vec, early_time_vec, min_buffer)
% For each entry in target_time_vec, we want to find the largest entry in
% early_time_vec whihc is still smaller than the entry in target_time_vec
% by at least min_buffer
% Ths is used to find the valid handshake of another routers pair that can be used
% during the calcualtion of the results of a current routers pair
% GET_INDEX_OFFSET_FOR_T_VEC_SYNC Function returns an index vector early_time_index such
% that early_time_vec(early_time_index) is aligned to target_time_vec
% In addition, the function returns the relative offset of the index vector
% with the row number
% (i.e. if at row number 8 the index is 10 the offset will be 10-8=2)
% Usage:
%     [early_time_index, index_offset] = get_index_offset_for_t_vec_sync(target_time_vec, early_time_vec, min_buffer)
%     
%     Inputs:
%         target_time_vec- A time vector which is expected to be after early_time_vec by at least min_buffer.
%         early_time_vec- A time vector which is expected to be before target_time_vec by at least min_buffer.
%         min_buffer- Extra buffer take into account a delay in availability.
%         
%     Outputs:
%         early_time_index- Index vector for the early_time_vec such that the same row in target_time_vec is the closest value that is always after min_buffer or more. i.e. adheres the constraint target_time_vec >= (early_time_vec(early_time_index) + min_buffer) .
%         index_offset- The offset of early_time_index from standard incremental index. i.e. early_time_index - 1:length(early_time_index).                  
        
    short_index = 1:length(early_time_vec);
    rep_short_index = repmat(short_index,ceil(length(target_time_vec)/length(early_time_vec)),1);
    index = rep_short_index(1:length(target_time_vec)).';        
    
    initial_offset = floor((target_time_vec-(early_time_vec(index) + min_buffer)) / mean(diff(early_time_vec))); % Estimated the expected offset
    early_time_index = max(min(index + initial_offset, length(early_time_vec)),1); % Create an offsetted index for the early vector
    
    prev_early_time_index = zeros(size(index)); % setup the while loop to run atleast once even in case the estimated offset was all zeros
    while  (0 < nnz(prev_early_time_index ~= early_time_index)) % stop when there are no more changes to the offsetted index

        prev_early_time_index = early_time_index;
        
        forward_offset_indices = (target_time_vec - (early_time_vec(early_time_index) + min_buffer)) > 0; % find all "legal" early vector indices
        early_time_index(forward_offset_indices) = min(early_time_index(forward_offset_indices) + 1, length(early_time_vec)); % try to offset forward all "causal" early vectors indices in order to find the lastest early vector indice which is still causal
        
        backward_offset_indices = target_time_vec - (early_time_vec(early_time_index) + min_buffer) < 0; % find all "ilegal" early vector indices
        early_time_index(backward_offset_indices) = max(early_time_index(backward_offset_indices) - 1, 1); % offset all "non-causal" early indices vector back so until the early vector is before the late vector
        
    end
    
    index_offset = early_time_index - index; 
    
    if (min(target_time_vec-(early_time_vec(early_time_index) + min_buffer)) < 0) % verify there are no non-causal indices
        
        I = find(target_time_vec-(early_time_vec(early_time_index) + min_buffer) < 0);
        if  (0 ~= nnz(0 ~= early_time_vec(early_time_index(I)))) 
            warning(['index is non causal in I = ' int2str(I(:).') '. Consider adding a first early_time_vec value of 0.']);
        end
    end
    
end

